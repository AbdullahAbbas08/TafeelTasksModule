/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function (config) {
  // Define changes to default configuration here. For example:
  config.language = 'ar';
  // config.uiColor = '#AADC6E';
  config.skin = 'office2013';
  config.extraPlugins = 'lineheight,tab,paging,arabicnumeric,extraStyleSheets';
  config.line_height = "1em;1.5em;2em;3em;4em;5em";
  config.tabSpaces = 6;
  config.extraAllowedContent = 'section[*]; header footer span(*)';

  var customFonts = [
    'AL-Mohanad/AL-Mohanad',
    'AL-Mohanad Bold/"AL-Mohanad Bold"',
    'DIN Next LT Arabic/"DIN Next LT Arabic"',
    'DIN Next LT Arabic Light/"DIN Next LT Arabic Light"',
    'Al-Mateen/Al-Mateen',
    'Kufyan Arabic Bold/"Kufyan Arabic Bold"',
    'GE SS Two Medium/"GE SS Two Medium"',
    'GE Dinar Two/"GE Dinar Two"',
    'GEDinar Two Light/"GEDinar-Two-Light"',
    'Swis721 Cn BT/"Swis721 Cn BT"',
    'Shorooq N1/"Shorooq_N1"',
    'JF Flat Regular/"JF Flat"', // check
    'Sakkal Majalla/"Sakkal Majalla"', // check
    'Apex Sans Bold/"Apex Sans Bold"',
    'Apex Sans Book/"Apex Sans Book"',
    'Apex Sans Medium/"Apex Sans Medium"',
    'Frutiger LT Arabic 45 Light/"Frutiger LT Arabic 45 Light"',
    'Frutiger LT Arabic 55 Roman/"Frutiger LT Arabic 55 Roman"',
    'Frutiger LT Arabic 65 Bold/"Frutiger LT Arabic 65 Bold"',
    'Frutiger LT Arabic 75 Black/"Frutiger LT Arabic 75 Black"',
    'Hacen Liner Print-out/"Hacen Liner Print-out"',
    'Hacen Liner Print-out Light/"Hacen Liner Print-out Light"',
    'Hacen Liner XL/"Hacen Liner XL"',
    'Hacen Liner XXL/"Hacen Liner XXL"',
    'Segoe UI/"Segoe UI"',
    'Segoe UI Semilight/"Segoe UI Semilight"',
    'Segoe UI Semibold/"Segoe UI Semibold"',
    'Segoe UI Bold/"Segoe UI Bold"',
    'Arabia Weather/"Arabia Weather"']; // check

  config.font_names = customFonts.join(';') + ';' + config.font_names;
};
