CKEDITOR.plugins.setLang('lineheight','ar', {
    title: 'تباعد الأسطر'
} );
