CKEDITOR.plugins.setLang('arabicnumeric','{LANGUAGE_CODE}', {
    title: '{ARABIC-NUMERIC}'
} );
