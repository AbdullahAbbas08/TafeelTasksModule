CKEDITOR.plugins.setLang('arabicnumeric', 'ar', {
    convertToArabicNumeric: 'تحويل إلي أرقام عربية',
    convertToEnglishNumeric: 'تحويل إلي أرقام إنجليزية',
});
