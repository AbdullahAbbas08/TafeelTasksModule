CKEDITOR.plugins.setLang('arabicnumeric', 'ar', {
  convertToArabicNumeric: 'Convert To Arabic Numeric',
  convertToEnglishNumeric: 'Convert To English Numeric',
});
