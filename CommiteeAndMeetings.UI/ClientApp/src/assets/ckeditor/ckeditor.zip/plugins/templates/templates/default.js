
CKEDITOR.addTemplates("default", {
  imagesPath: CKEDITOR.getUrl(CKEDITOR.plugins.getPath("templates") + "templates/images/"),
  templates: getTemplates(),
});

function getTemplates() {
  var templates = [];
  var user = JSON.parse(localStorage['user']);

  var xhr = new XMLHttpRequest();
  xhr.open('GET', '/api/LetterTemplate/GetLetterTemplateForUser?organizationId=' + user.organizationId + '', false);
  xhr.onload = function () {
    var res = JSON.parse(xhr.responseText);
    for (var i = 0; i < res.length; i++) {
      templates.push({
        title: res[i].letterTemplateName,
        html: res[i].text,
        image: /*'template1.gif'*/'',
        description: '',
      });
    }
    //xhr.abort();
  };
  xhr.send();
  return templates;
}
