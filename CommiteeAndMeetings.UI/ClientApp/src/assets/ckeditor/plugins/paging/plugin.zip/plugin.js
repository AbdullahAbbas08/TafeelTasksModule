(function () {
  CKEDITOR.plugins.add('paging', {
    init: function (editor) {

      var template;
      var loaded = false;

      editor.setData('<section></section>');

      editor.on('instanceReady', function () {
        generatePagesNumbers();
      });

      editor.on('change', function () {
        autoPaging(editor);
        generatePagesNumbers();
        getTemplate(editor);
      });

      //on move to another row
      editor.on('selectionChange', function () {
        var startNode = editor.getSelection().getStartElement();
        var pageNumber, previousSibling;
        if (startNode.$.tagName === 'SECTION') {
          if (!startNode.$.previousSibling) {
            pageNumber = 1;
          } else {
            pageNumber = 1;
            previousSibling = startNode.$.previousSibling;
            while (previousSibling) {
              pageNumber++;
              previousSibling = previousSibling.previousSibling;
            }
          }
        } else {
          var ancestor = startNode.$.parentNode;
          while (ancestor) {
            if (ancestor.tagName === 'SECTION') {
              if (!ancestor.previousSibling) {
                pageNumber = 1;
              } else {
                pageNumber = 1;
                previousSibling = ancestor.previousSibling;
                while (previousSibling) {
                  pageNumber++;
                  previousSibling = previousSibling.previousSibling;
                }
              }
              break;
            }
            ancestor = ancestor.parentNode;
          }
        }
      });

      editor.on('key', function (e) {
        var selection = e.editor.getSelection();
        if (selection) {
          var ranges = selection.getRanges();
          if (ranges != null) {
            var range = ranges[0];
            if (range != null) {
              range = range.clone();

              var startNode = range.startContainer;
              var endNode = range.endContainer;

              var cancelEvent = false;

              var pos = startNode.getPosition(endNode);
              var ancestor;
              switch (pos) {
                case CKEDITOR.POSITION_IDENTICAL: {
                  switch (e.data.keyCode) {
                    case 8: { //BACKSPACE
                      if (range.startOffset === 0) {
                        if (startNode.$.tagName === 'SECTION' && !startNode.$.previousSibling) {
                          cancelEvent = true;
                          break;
                        }
                        ancestor = startNode.$.parentNode;
                        if (ancestor && ancestor.tagName === 'SECTION') {
                          if (!startNode.$.previousSibling && !ancestor.previousSibling) {
                            cancelEvent = true;
                            break;
                          }
                        }
                      }
                      break;
                    }
                    default: { return true; }
                  }
                  break;
                }
                case CKEDITOR.POSITION_DISCONNECTED: {
                  cancelEvent = true;
                  break;
                }
                default: { break; }
              }

              if (cancelEvent) {
                //Cancel the event
                e.cancelBubble = true;
                e.returnValue = false;
                e.cancel();
                e.stop();
                return false;
              }
            }
          }
        }
        return true;
      });


      function getTemplate(editor) {
        if (!loaded) {
          const data = editor.getData();
          if (data.includes('<header>') || data.includes('<footer>')) {
            loaded = true;
            const header = $(editor.document.$).contents().find('body > section > header').length > 0 ? $(editor.document.$).contents().find('body > section > header')[0].outerHTML : '';
            const footer = $(editor.document.$).contents().find('body > section > footer').length > 0 ? $(editor.document.$).contents().find('body > section > footer')[0].outerHTML : '';
            template = (header && footer) ? { header: header, footer: footer } : null;
          }
        }
      }

      function autoPaging(editor) {
        var editorContents = $(editor.document.$).contents();
        var sections = editorContents.find('body > section');
        if (!sections.length) {
          var bodyContents = editorContents.find('body >');
          if (bodyContents.length) {
            bodyContents.wrapAll('<section></section>');
          } else {
            editorContents.find('body').html('<section></section>');
          }
          return;
        }
        var sectionHeight = sections.eq(0).height();
        var footerHeight = sections.eq(0).find('footer').outerHeight();
        footerHeight = footerHeight ? footerHeight : 0;
        sections.each(sectionCheck);

        function sectionCheck(index, section) {
          var exceededElementsParents = $(section).find('> :not(footer)').filter(function (i, ele) {
            return ($(ele).position().top + $(ele).outerHeight()) > (sectionHeight - footerHeight) && ($(ele).outerHeight() > (sectionHeight - footerHeight))
          });

          if (exceededElementsParents.length) {
            exceededElementsParents.replaceWith(exceededElementsParents.html());
            sectionCheck(index, section);
            return;
          }

          var exceededElements = $(section).find('> :not(footer)').filter(function (i, ele) {
            return ($(ele).position().top + $(ele).outerHeight()) > (sectionHeight - footerHeight) && !($(ele).outerHeight() > (sectionHeight - footerHeight))
          });
          var nextSection = sections[index + 1];

          if (exceededElements.length) {
            var ranges = editor.getSelection().getRanges();
            if (!nextSection) {
              const tmplt = template ? (template.header + template.footer) : '';
              if (tmplt) {
                $(section).after($('<section data-page="' + (index + 2) + '">' + tmplt + '</section>')).next('section').find('header').after(exceededElements.detach());
              } else {
                $(section).after($('<section data-page="' + (index + 2) + '"></section>'))
                  .append(exceededElements.detach())
              }
            } else {
              $(nextSection).prepend(exceededElements.detach());
            }
            editor.getSelection().selectRanges(ranges);
            fireChange();
          }

          //can't reach here !
          if (nextSection) {
            var lastElementInSection = $(section).find('> :not(footer)').last();
            if (lastElementInSection) {
              var emptySpaceHeight = (sectionHeight - footerHeight) - (lastElementInSection.position().top + lastElementInSection.outerHeight());
              var firstElementInNextSection = $(nextSection).find('> :not(header)').first();
              var firstElementInNextSectionHeight = firstElementInNextSection.outerHeight();
              if (emptySpaceHeight > firstElementInNextSectionHeight) {
                var ranges = editor.getSelection().getRanges();
                var footer = $(section).find('> footer');
                footer[0] ? footer[0].before(firstElementInNextSection.detach()) : $(section).append(firstElementInNextSection.detach());
                editor.getSelection().selectRanges(ranges);
                fireChange();
              }
            }
          }
        }
      }

      function generatePagesNumbers() {
        $(editor.document.$).contents().find('body > section').each(function (i) {
          $(this).attr('data-page', i + 1);
        });
      }

      function fireChange() {
        setTimeout(function () { editor.fire('change'); }, 50);
      }
    }
  });
})();
